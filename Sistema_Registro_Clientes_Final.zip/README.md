# 🧾 Sistema de Registro de Clientes

Sistema simples e eficiente para cadastro e gerenciamento de clientes entre escritórios associados.

---

## 🚀 Funcionalidades

✅ Cadastro de clientes (com campos: nome, CPF, escritório, tipo de ação, pendências, etc.)  
✅ Armazenamento em **banco SQLite único**, com **tabelas separadas por escritório**  
✅ Exportação de dados:
- **CSV** — exporta uma tabela específica ou todas  
- **PDF** — gera relatório formatado com cabeçalho e data  
✅ Estrutura leve e pronta para deploy  
✅ Suporte a **logo personalizada** (para PDF)

---

## 🗂️ Estrutura do projeto

```
/ (diretório raiz)
│
├── app.py                # Backend Flask
├── database.db           # Banco SQLite
├── index.html            # Formulário de cadastro
├── table.html            # Visualização de registros
├── style.css             # Estilos modernos e responsivos
├── script.js             # Funções simples de frontend
├── requirements.txt      # Dependências (Flask + ReportLab)
└── /logo/                # Coloque aqui o arquivo logo.png (opcional)
```

---

## ⚙️ Execução local

### 1. Instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Executar o servidor Flask
```bash
python app.py
```

### 3. Acessar no navegador
```
http://127.0.0.1:5000
```

---

## 📤 Exportação de dados

Na página **Registros (`table.html`)**, é possível exportar:
- **CSV** → `/export/csv?office=NomeDoEscritorio`
- **PDF** → `/export/pdf?office=NomeDoEscritorio`
  
Ou use `?office=all` para exportar **todas as tabelas**.

---

## 🖼️ Adicionando a logo no PDF

1. Crie um arquivo `logo.png`.
2. Coloque dentro da pasta `/logo/`.
3. O sistema automaticamente insere o logo no canto superior esquerdo dos PDFs exportados.

---

## 🌐 Publicação no GitHub Pages (modo estático)

> ⚠️ Atenção: o GitHub Pages só suporta conteúdo **estático (HTML/CSS/JS)**.
> O backend Flask **não funcionará** nesse modo — apenas a interface.

1. Suba todos os arquivos (exceto `app.py`, `database.db` e `requirements.txt`).
2. Vá em **Settings → Pages → Branch: main → / (root)**.
3. O site ficará disponível em `https://seuusuario.github.io/nome-do-repo/`.

---

## ☁️ Publicação no HostGator (modo Flask dinâmico)

1. Faça upload de **todos os arquivos** (inclusive o `app.py` e o banco `database.db`).
2. No painel HostGator, configure um **ambiente Python/Flask**:
   - Caminho do aplicativo: `/app.py`
   - Variável de ambiente: `FLASK_APP=app.py`
3. Inicie o servidor.  
4. O site funcionará com cadastro, exportações e banco de dados ativos.

---

## 🧩 Requisitos

- Python 3.8+
- Flask
- ReportLab

Instalação manual:
```bash
pip install flask reportlab
```

---

## 📄 Licença

Projeto interno — uso restrito aos escritórios associados.  
Desenvolvido com ❤️ por POTTHOFF.
