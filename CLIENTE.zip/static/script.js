// Placeholder for later JS functionality.
console.log('script loaded');
